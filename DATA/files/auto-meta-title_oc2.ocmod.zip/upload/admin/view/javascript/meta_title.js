/* Auto Meta Title from name */

function setTitle(source, dest, rewrite) {
	var name = $("input[name='"+source+"']").val();
	if (name != undefined) {
		$("input[name='"+source+"']").change(function(){
			var name = $("input[name='"+source+"']").val();
			var key = $("input[name='"+dest+"']").val();
			if ((key == '')||(rewrite))
				$("input[name='"+dest+"']").val(name);
		});
	}
}

$(document).ready(function(){
	
	// Products
	setTitle("product_description\\[1\\]\\[name\\]", "product_description\\[1\\]\\[meta_title\\]", false);
	setTitle("product_description\\[2\\]\\[name\\]", "product_description\\[2\\]\\[meta_title\\]", false);
	setTitle("product_description\\[3\\]\\[name\\]", "product_description\\[3\\]\\[meta_title\\]", false);
	setTitle("product_description\\[4\\]\\[name\\]", "product_description\\[4\\]\\[meta_title\\]", false);
	
	// Categories
	setTitle("category_description\\[1\\]\\[name\\]", "category_description\\[1\\]\\[meta_title\\]", false);
	setTitle("category_description\\[2\\]\\[name\\]", "category_description\\[2\\]\\[meta_title\\]", false);
	setTitle("category_description\\[3\\]\\[name\\]", "category_description\\[3\\]\\[meta_title\\]", false);
	setTitle("category_description\\[4\\]\\[name\\]", "category_description\\[4\\]\\[meta_title\\]", false);

	// Pages
	setTitle("information_description\\[1\\]\\[title\\]", "information_description\\[1\\]\\[meta_title\\]", false);
	setTitle("information_description\\[2\\]\\[title\\]", "information_description\\[2\\]\\[meta_title\\]", false);
	setTitle("information_description\\[3\\]\\[title\\]", "information_description\\[3\\]\\[meta_title\\]", false);
	setTitle("information_description\\[4\\]\\[title\\]", "information_description\\[4\\]\\[meta_title\\]", false);
	
});
