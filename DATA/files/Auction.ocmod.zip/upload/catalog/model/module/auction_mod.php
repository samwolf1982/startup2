<?php

################################################################################################
# Product auction for Opencart 2.0.x From webkul http://webkul.com    #
################################################################################################
class ModelModuleAuctionMod extends Model {
	
	public function getAuctionProduct($product_id){	
		$date = new DateTime('2014-06-1', new DateTimeZone($this->config->get('wkproduct_auction_timezone_set')));
		$zone = $date->format('P');
		$query = "SELECT CONVERT_TZ(NOW(), @@session.time_zone, '$zone') as time;";
		$data = $this->db->query($query)->row;
		$time = date("Y-m-d H:i", strtotime($data['time']));

	      $result = $this->db->query("SELECT * FROM ".DB_PREFIX."wkauction wa LEFT JOIN ".DB_PREFIX."product p ON (wa.product_id = p.product_id) WHERE wa.product_id = '".(int)$product_id."' AND wa.start_date <= '".$time."' AND end_date >= '".$time."' AND wa.isauction = '1' ")->row;
	      
	    return $result;
	}

	public function remainProducts($limit, $products){
		
		$new = implode(',',$products);				
		$data = $this->db->query("SELECT wa.product_id FROM ".DB_PREFIX."wkauction wa LEFT JOIN ".DB_PREFIX."product p ON (wa.product_id = p.product_id) WHERE wa.product_id NOT IN (".$new.") AND wa.start_date <= '".$time."' AND end_date >= '".$time."' ORDER BY wa.end_date ASC LIMIT ".$limit."")->rows;
		
		return $data;
	}
}

?>
