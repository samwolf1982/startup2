<?php
// Heading
$_['heading_title'] = 'Аукцион';


//Text
$_['text_bidnow'] = 'Сделать ставку';
$_['text_minbid'] = 'Мин. ставка';
$_['text_maxbid'] = 'Макс. ставка';

