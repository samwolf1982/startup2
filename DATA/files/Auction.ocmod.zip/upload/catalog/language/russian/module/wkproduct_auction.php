<?php
// Заголовок
$_['heading_title'] = 'Аукцион товаров';

// Текст
$_['text_biddetails'] = 'Детали ставок';
$_['text_bidlist'] = 'Список ставок';
$_['text_bidnow'] = 'Ставка';
$_['text_list_bids'] = 'Список ставок';
$_['text_name'] = 'Имя';
$_['text_bids'] = 'Ставки';
$_['text_nobids'] = 'Нет ставок пока!';

$_['entry_auction'] = 'Аукцион';
$_['entry_winner'] = 'Поздравление вы выиграли этот Аукцион';
$_['entry_time_left'] = 'Оставшееся время:';
$_['entry_bids'] = 'Всего ставок';
$_['entry_min_price'] = 'Мин. цена';
$_['entry_max_price'] = 'Макс. цена';
$_['entry_start_time'] = 'Время старта';
$_['entry_close_time'] = 'Время закрытия';
$_['entry_your_price'] = 'Ваша цена: (крайняя)';
$_['entry_thnaks'] = 'Спасибо за вашу ставку';
$_['entry_no_bids'] = 'Нет ставок! Будьте первым';
$_['entry_bids_error'] = 'Пожалуйста, введите сумму ставки';
$_['entry_ammount_error'] = 'Количество должно быть цифрами';
$_['entry_login_error'] = 'Пожалуйста, войдите, на чтобы сделать ставку';
$_['entry_ammount_less_error'] = 'Сумма должна быть больше, чем в прошлой ставке!';
$_['entry_ammount_range_error'] = 'Количество должно быть в диапазоне';

$_['text_quantity'] = 'Аукцион будет проводится на минимальном количестве';

$_['error_quantity'] = 'Минимальное количество для этого товара ';
$_['error_quantity1'] = ' ';


//Сообщения
$_['bid_message_seller_message1'] = 'Ваш Аукцион товаров (';
$_['bid_message_seller_message2'] = ') выиграл';
$_['bid_message_seller_message3'] = 'и купон-код';
$_['bid_message_seller_message4'] = 'и купон действителен до';
$_['bid_message_seller_subject'] = 'Уведомление';

$_['bid_message_customer_message1'] = 'Поздравляем! Вы выиграли предложение для продукта (';
$_['bid_message_customer_message2'] = ') ваш купон код';
$_['bid_message_customer_message3'] = 'и купон действителен до';
$_['bid_message_customer_message4'] = 'поэтому, пожалуйста, используйте этот код купона для купить этот продукт';
$_['bid_message_customer_title'] = 'Вы выиграли предложение ...';
$_['bid_message_customer_subject'] = 'торгов Победа уведомления';

$_['bid_message_admin_message1'] = 'Клиент (';
$_['bid_message_admin_message2'] = ') выиграла тендер на продукт (';
$_['bid_message_admin_message3'] = '), его код купона является';
$_['bid_message_admin_message4'] = 'и купон действителен до';
$_['bid_message_customer_title'] = 'Ваш продукт заявка была завершена ...';
$_['bid_message_customer_subject'] = '. торгов';
?>
