<?php
// Heading 
$_['heading_title']     = 'Auction';
$_['entry_empty']     = 'Currently no Products available in Auction. Please come Back after some Time...  ';

//text
$_['text_currentAuct'] = 'Current Auction';
$_['text_recentWinner'] = 'Recent Winners';
$_['text_allProduct'] = 'All Products';
$_['text_sTime'] = 'Start Time';
$_['text_eTime'] = 'End Time';
$_['text_minBid'] = 'Min Bid';
$_['text_maxBid'] = 'Max Bid';
$_['text_bidNow'] = ' Bid Now';
$_['text_winnerBid'] = 'Winning Bid -';
$_['text_winnerName'] = 'Winner Name -';

?>