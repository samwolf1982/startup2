<?php
// Heading
$_['heading_title'] = 'Featured';

// Text
$_['limited_time_offer']      = 'LIMITED TIME OFFER';