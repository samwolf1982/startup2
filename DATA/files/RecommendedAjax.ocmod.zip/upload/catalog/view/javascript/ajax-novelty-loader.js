/************************   AJAX  NOVELTY LOADER   ************************/
/************************    DOMUS159@GMAIL.COM    ************************/
/**********************  проверено на ocStore 2.1.x  **********************/

var waiting = false;

function getNextNoveltyPage($name, url) {
	var $novelty_block = '.row.product_' + $name;
	var $load_more = '.load_more_' + $name;
	if (waiting) return;
    // if (pages_count >= pages.length) return;
	waiting = true;
	old_load_more = $($load_more).html();
	$($load_more).html('ЗАГРУЗКА');
	$.ajax({
		url:url, 
		type:"GET", 
		data:'',
		success:function (data) {
			console.log("ajax success!");
			$data = $(data);
			$($load_more).html(old_load_more);
			if ($data) {
				if ($data.find($novelty_block).length > 0)    {
					$($load_more).parent().before($data.find($novelty_block));
				}
			}
			waiting = false;
		}
	});
}