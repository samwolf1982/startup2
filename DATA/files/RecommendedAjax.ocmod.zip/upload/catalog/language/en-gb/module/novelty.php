<?php
// Heading
$_['heading_title'] = 'Recommended';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_button']      = 'Load More';