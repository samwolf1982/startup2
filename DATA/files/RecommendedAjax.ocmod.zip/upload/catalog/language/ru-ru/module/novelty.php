<?php
// Heading
$_['heading_title'] = 'Рекомендуемые';

// Text
$_['text_tax']      = 'Без налога:';
$_['text_button']      = 'Загрузить еще';