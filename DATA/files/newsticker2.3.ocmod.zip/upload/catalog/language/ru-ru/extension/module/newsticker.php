<?php
// Heading
$_['heading_title'] = 'Что нового?';

// Text
$_['limited_time_offer']      = 'Что нового?';