<?php
// Heading
$_['heading_title']    = 'Что нового?';

// Text
$_['text_extension']   = 'Модули';
$_['text_success']     = 'Успешно: Вы отредактировали модуль!';
$_['text_edit']        = 'Редактирование Что нового?';

// Entry
$_['entry_name']       = 'Название модуля';
$_['entry_Newsticker'] = 'Что нового?';
$_['entry_dimension']  = 'Размеры (Ш x В) и тип обрезки';
$_['entry_width']      = 'Ширина';
$_['entry_height']     = 'Высота';
$_['entry_status']     = 'Статус';
$_['entry_color']       = 'Цвет';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на управление модулем!';
$_['error_name']       = 'Название модуля должно содержать от 3 до 64 символов!';
$_['error_width']      = 'Ширина обязательно!';
$_['error_height']     = 'Высота обязательно!';

$_['entry_newsticker'] = 'Выберите ленту новостей';

$_['limited_time_offer'] = 'Заголовок ленты';
$_['insertfromhere'] = 'Создать ленту новостей ';
$_['here'] = 'тут';


