<?php
// Text 
$_['text_select_series_item'] = 'Please select';
$_['text_in_the_same_series'] = 'In the same series';
?>