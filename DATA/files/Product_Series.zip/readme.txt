ABOUT:
=========
 * @version 1.6.2

Linking multiple products into series is now easier than ever.
Here's what you need: Product Series Extension

With this extension, you can now link multiple products into a collection or series.
Customers can see images and links to other products in the same series or collection with the one they are viewing.

Please note that this module is an alternate version of Color Series, only one can be used at a time not both.
You can update from Color Series to Product Series but all existing colors will be lost.

FEATURES:
==================
This mod enhances your OpenCart store with the ability to:
- Create Product Series that link to multiple products.
- Assign images to items in a series.
- Products in the same series are displayed in category and product pages.
Whenever viewing any product, users can also see all other products in the same series

COMPATIBILITY:
==================
- OpenCart 2
- Support OpenCart multi-store. You want Striped products to be visible only on your Women Store, Plain ones - only Men Store, and Colourful ones - on both? Sure you can.
- Export/Import extension
- Shoppica2 theme, RGen Cupid, Ribbon... themes
- Compatible with most themes
PLUS
Customising the mod to work with your theme (custom or not) is provided at no extra cost

FRESH INSTALL (OPENCART):
==================
-If you have not, install VqMod on your OpenCart store. The latest version can be downloaded from http://code.google.com/p/vqmod/
-Make sure VqMod has been installed completely and is running by browsing to YOUR_SITE/vqmod/install. It must displays VQMOD ALREADY INSTALLED!
-Upload admin, catalog, vqmod folders to your OpenCart store directory (no core files will be overwritten)
-If you use Export/Import extension, also upload extra/product_series_export_import.xml to vqmod/xml folder
-Enable permission: System/User/User Groups/Top Administrator, enable access and modify permissions for module/pds
-IMPORTANT: Go to Extensions/Modules and choose to install Product Series
-Choose to Edit Product Series and configure as needed

UPDATE FROM AN OLDER VERSION:
==================
-Upload admin, catalog and vqmod folders to your OpenCart store directory
-If you use Export/Import extension, also upload extra/product_series_export_import.xml to vqmod/xml folder
-Go to Admin/Extensions/Modules and choose to edit Product Series
-Configure as needed

UPGRADE FROM COLOR SERIES MOD:
==================
-Upload admin, catalog, pds and vqmod folders to your OpenCart store directory, select to overwrite existing files (no core files will be overwritten, only old files from Color Series mod)
-Delete all xml files that has name start with "color_series" in vqmod\xml
-Open YOUR_STORE_SITE/pds/update (e.g http://awesomestore.com/pds/update) using your browser.
There will be a SUCCESS message indicating the mod has been updated successfully.
-Delete pds folder
-Enable permission: System/User/User Groups/Top Administrator, enable access and modify permissions for module/pds
-Go to Extensions/Modules and choose to install Product Series
-Choose to Edit Product Series and configure as needed

HOW TO USE:
==================
+ CREATE A SERIES FROM EXISTING PRODUCTS:
- From Product List page, select one or more products to be added to the new Series (by checking the checkboxes on the left)
- Click "Create Series" button on the top right
- A new Series will be created and added to the list

OR

- Insert a New Product or Edit an existing one
- Enter all the require data (name, description, prices, images etc)
- Under Product Series Tab, select "This product Represents a Series"

+ ADD PRODUCTS TO AN EXISTING SERIES:
- Insert a New Product or Edit an existing one
- Enter all the require data (name, description, prices, images etc)
- Under Product Series Tab, select "This product Belongs to a Series"
- Select a Series Image (optional)
- Choose a Series to link to

+ EXAMPLE: you want a Series with 2 items: CoolNo1 and CoolNo2
- Select CoolNo1 and CoolNo2 from Product List
- Click "Create Series"
- A new Series will be created and named "CoolNo1 Series" (" Series" is appended to the first selected product's name)
- Rename the Series as needed.
