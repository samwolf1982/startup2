<?php
// Text 
$_['text_select_series_item'] = 'Choise model';
$_['text_in_the_same_series'] = 'Available models';
?>