<?php
// Heading 
$_['heading_title']  = 'Предварительный просмотр';
?>