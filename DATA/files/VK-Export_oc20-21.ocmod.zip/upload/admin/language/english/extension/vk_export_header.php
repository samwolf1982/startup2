<?php

$_['text_vk_export']           = 'Экспорт товаров ВК';
$_['text_vk_export_albums']    = 'Альбомы';
$_['text_vk_export_market']    = 'Категории ВК';
$_['text_vk_export_setting']    = 'Настройки';
$_['text_vk_export_cron_report']    = 'Отчеты запуска по cron';

?>
