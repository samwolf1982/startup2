<?php
// Heading
$_['heading_title']          = 'Категории ВК';
$_['heading_title_module']   = 'Экспорт товаров Вконтакте';

// Column
$_['entry_category']                    = 'Категория';

// button
$_['button_add_album']                  = 'Добавить категорию';
$_['button_remove']                     = 'Удалить';

// Error
$_['error_permission']       = 'У Вас нет прав для изменения товаров!';
?>
