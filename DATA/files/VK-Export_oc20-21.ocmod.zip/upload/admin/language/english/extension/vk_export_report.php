<?php
// Heading
$_['heading_title']          = 'Отчеты запуска по cron';
$_['heading_title_module']   = 'Экспорт товаров Вконтакте';


?>
