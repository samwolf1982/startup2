<?php
// Heading
$_['heading_title'] 	= 'Our News';
 
// Text
$_['text_title'] 		= 'Title';
$_['text_description'] 	= 'Description';
$_['text_date'] 		= 'Date Added';
$_['text_view'] 		= 'View';
$_['text_error'] 		= 'The page you are looking for cannot be found.';