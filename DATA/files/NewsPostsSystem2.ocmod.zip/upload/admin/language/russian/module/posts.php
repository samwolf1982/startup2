<?php
// Heading
$_['heading_title']    = '<strong>Блог Статьи</strong> от <a href="http://free-it.ru">Samdev</a>';

$_['text_module']      = 'Модуль';
$_['text_success']     = 'Успешно!';
$_['text_edit']        = 'Редактировать';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас нет прав!';