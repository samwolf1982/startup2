<?php
//Entry
$_['entry_master_option'] 				= 'Parent option:';
$_['entry_master_option_value'] 		= 'Parent option value:';
?>