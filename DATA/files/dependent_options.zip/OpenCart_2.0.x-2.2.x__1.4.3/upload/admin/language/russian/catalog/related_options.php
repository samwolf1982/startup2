<?php
//Entry
$_['entry_master_option'] 				= 'Родительская опция:';
$_['entry_master_option_value'] 		= 'Значение родительской опции:';
?>