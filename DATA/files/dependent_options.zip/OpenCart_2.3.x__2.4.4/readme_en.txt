Module "Related / Dependent options" 2.4.x

It has been tested on OpenCart 2.3.0.2


Installation:

1. Copy files from the Upload folder and paste into the site root folder directory. Existing files won't be deleted.

2. At your Opencart site administration open 'Extensions' - 'Extensions Installer' download file  /system_ocmod/install.ocmod.xml.
Than, depends on your template (subfolder name) - upload from folder templates_ocmod/default/options_related_default.ocmod.xml (for default theme).
At your Opencart site administration open 'Extensions' - 'Modifications'. Click 'Refresh'.

3. At your Opencart site administration open 'Extensions' - 'Modules'. Click "Install" opposite "Related / Dependent options".

4. Installation is finished. 

For editing related-to-option values open tab "Options" by a certain product at the Administration panel and fill in "Parent option" and "Parent option value".

If you renew this extension please follow this instruction:
1. Step 1 from installation process
2. Go to modification and checkbox near Related / Dependent options and click delete
3. Step 2 from installation process 