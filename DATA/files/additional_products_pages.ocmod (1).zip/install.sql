INSERT INTO oc_url_alias (query, keyword)
SELECT 'product/mostviewed', 'popular-products'
FROM dual
	WHERE NOT EXISTS
	(SELECT * FROM oc_url_alias WHERE oc_url_alias.query = 'product/mostviewed');

INSERT INTO oc_url_alias (query, keyword)
SELECT 'product/bestseller', 'bestsellers'
FROM dual
	WHERE NOT EXISTS
	(SELECT * FROM oc_url_alias WHERE oc_url_alias.query = 'product/bestseller');

INSERT INTO oc_url_alias (query, keyword)
SELECT 'product/latest', 'latest-products'
FROM dual
	WHERE NOT EXISTS
	(SELECT * FROM oc_url_alias WHERE oc_url_alias.query = 'product/latest');

INSERT INTO oc_url_alias (query, keyword)
SELECT 'product/all-products', 'all-products'
FROM dual
	WHERE NOT EXISTS
	(SELECT * FROM oc_url_alias WHERE oc_url_alias.query = 'product/all-products');