<?php

class AdditionalPageName
{
    const LATEST = 'latest';
    const POPULAR = 'mostviewed';
    const BESTSELLERS = 'bestseller';
    const ALL_PRODUCTS = 'all-products';
}
