<?php
// Heading
$_['heading_title']       = 'Russian Post';

// Text
$_['text_all_users']      = 'All users';
$_['text_shipping']       = 'Shipping';
$_['text_license']        = 'License';
$_['text_edit']           = 'Russian Post - license';

// Entry
$_['entry_key']           = 'Entry key:';


// Error
$_['error_permission']  = 'Warning: You do not have permission to modify Russian Post shipping!';
$_['error_warning']     = 'Warning: Please check the form carefully for errors!';
?>