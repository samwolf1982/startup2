<?php
// Heading
$_['heading_title']       = 'Почта России';

// Text
$_['text_all_users']      = 'Все пользователи';
$_['text_shipping']       = 'Доставка';
$_['text_license']        = 'Лицензия';
$_['text_edit']           = 'Почта России - лицензия';

// Entry
$_['entry_key']           = 'Введите ключ:';


// Error
$_['error_permission']    = 'У Вас нет прав для изменения этого модуля!';
$_['error_warning']       = 'Заполните все поля!';
?>