<?php
//Text
 $_['text_product_currency'] = '<span style="color: #bbb;font-size:90%;"><i>price in {title}</i>: {price}</span><br />';
?>
