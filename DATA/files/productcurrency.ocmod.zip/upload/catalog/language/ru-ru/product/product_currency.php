<?php
//Text
 $_['text_product_currency'] = '<span style="color: #bbb;font-size:90%;"><i>цена в {title}</i>: {price}</span><br />';
?>
