<?php
// Heading
$_['heading_title']    = 'Newsletters';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified newsletters!';
$_['text_edit']        = 'Edit newsletters Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Newsletters module!';
