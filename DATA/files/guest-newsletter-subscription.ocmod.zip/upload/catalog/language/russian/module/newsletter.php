<?php
// Heading
$_['heading_title']     = 'Подписаться на рассылку';

