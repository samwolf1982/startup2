<?php
// Text
$_['text_title']       = 'Transfer MoneyGram';
$_['text_instruction'] = 'Please transfer to MoneyGram Account Number';
$_['text_description'] = 'Please transfer the total amount to the following account.';
$_['text_payment'] = 'Order will be sent after we receive payment from you.';
?>