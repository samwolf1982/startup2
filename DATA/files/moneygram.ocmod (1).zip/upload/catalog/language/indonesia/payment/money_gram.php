<?php
// Text
$_['text_title']       = 'Transfer via Bank BRI';
$_['text_instruction'] = 'Silahkan Anda Transfer ke Nomor Rekening BRI';
$_['text_description'] = 'Silahkan mentransfer jumlah total ke rekening bank berikut.';
$_['text_payment']     = 'Order akan kami kirim setelah kami menerima pembayaran dari anda..';
?>