<?php

// Heading
$_['heading_title']       = 'Расширенные отчеты по заказам и продажам';
$_['curr_heading_title']       = 'Расширенные отчеты по заказам и продажам';
$_['heading_title_h1']       = 'Расширенные отчеты по заказам и продажам';
$_['heading_title_h2']       = ' <a target="_blank" href="https://opencart2x.ru">другие модули</a>';
// Text
$_['text_module']         = 'Модули';
$_['text_success']        = 'Модуль успешно обновлен!';
$_['text_content_top']    = 'Верх страницы';
$_['text_content_bottom'] = 'Низ страницы';
$_['text_column_left']    = 'Левая колонка';
$_['text_column_right']   = 'Правая колонка';
$_['text_none']   = '';

// Labels
$_['module_label'] = array(
	'label_top_product' => 'Ходовой товар',
	'label_client_group' => 'Группы клиентов',
	'label_ship_region' => 'Заказы по регионам (доставка)',
	'label_man_product' => 'Производители (объем продуктов)',
	'label_order_sales' => 'Оборот заказов',
	'label_client_orders' => 'Клиенты',
	'label_option_sales' => 'Опции',
	'label_filter_date_start' => 'Дата начала',
	'label_filter_date_end' => 'Дата окончания',
	'label_filter_date_start_month' => 'Месяц (начало)',
	'label_filter_date_start_year' => 'Год (начало)',
	'label_filter_date_end_month' => 'Месяц (конец)',
	'label_filter_date_end_year' => 'Год (конец)',
	'label_filter_order_status' => 'Статус заказа',
	'label_filter_cat' => 'Категория',
	'label_filter_manufact' => 'Производитель',
	'label_filter_sort' => 'Сортировка',
	'list_client_orders_modes' => 'Режим отчета'
);

// Buttons
$_['module_button'] = array(
	'button_cancel' => 'Вернуться',
	'button_filter' => 'Фильтровать',
	'button_csv' => 'CSV файл'
);

// Table headers_list
$_['module_table_header'] = array(
	'table_top_product_cat' => 'Категория',
	'table_top_product_name' => 'Название',
	'table_top_product_model' => 'Модель',
	'table_top_product_manufact' => 'Производитель',
	'table_top_product_count' => 'Количество',
	'table_top_product_cost' => 'Итого',
	'table_client_group_name' => 'Группа клиентов',
	'table_client_group_count' => 'Количество',
	'table_client_group_cost' => 'Итого',
	'table_ship_region_name' => 'Страна > Регион',
	'table_ship_region_count' => 'Количество',
	'table_ship_region_cost' => 'Итого',
	'table_man_product_name' => 'Производитель',
	'table_man_product_count' => 'Количество',
	'table_man_product_cost' => 'Итого',
	'table_order_sales_name' => 'Месяц',
	'table_order_sales_count' => 'Количество',
	'table_order_sales_cost' => 'Итого',
	'table_client_orders_name' => 'Имя клиента',
	'table_client_orders_email' => 'E-mail',
	'table_client_orders_phone' => 'Телефон',
	'table_client_orders_city' => 'Город',
	'table_client_orders_status' => 'Статус',
	'table_client_orders_date_added' => 'Регистрация',
	'table_client_orders_last_order' => '# Последний заказ',
	'table_client_orders_count' => 'Количество',
	'table_client_orders_cost' => 'Итого',
	'table_option_sales_name' => 'Наименование опции',
	'table_option_sales_count' => 'Количество',
	'table_option_sales_cost' => 'Итого',
	'table_footer_all' => 'Итого'
);

// Error
$_['error_permission']    = 'У Вас нет прав для изменения модуля Расширенные отчеты!';
