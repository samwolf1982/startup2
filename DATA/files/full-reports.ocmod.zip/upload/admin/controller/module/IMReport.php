<?php
class ControllerModuleIMReport extends Controller {
	private $error = array(); 
	
	// Стартовая страница контроллера
	public function index() {   
		$this->load->language('module/IMReport');

		$this->document->setTitle($this->language->get('curr_heading_title'));
		
		// Поддержка графиков
		$this->document->addScript('view/javascript/jquery/flot/jquery.flot.js');
		$this->document->addScript('view/javascript/jquery/flot/jquery.flot.resize.min.js');

		// Загрузка моделей
		$this->load->model('setting/setting');
		$this->load->model('module/IMReport');
				
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('IMReport', $this->request->post);		
					
			$this->session->data['success'] = $this->language->get('text_success');
						
			$this->response->redirect($this->url->link('module/IMReport', 'token=' . $this->session->data['token'], 'SSL'));
		}
		
		// Данные
		$data = array();
		
		////////////////////////////////////
		// Стандартные данные
		////////////////////////////////////
		
		$data['heading_title'] = $this->language->get('heading_title');
		$data['h1_text'] = $this->language->get('heading_title_h1');
		$data['h2_text'] = $this->language->get('heading_title_h2');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_content_top'] = $this->language->get('text_content_top');
		$data['text_content_bottom'] = $this->language->get('text_content_bottom');		
		$data['text_column_left'] = $this->language->get('text_column_left');
		$data['text_column_right'] = $this->language->get('text_column_right');
		
		$data['entry_layout'] = $this->language->get('entry_layout');
		$data['entry_position'] = $this->language->get('entry_position');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_sort_order'] = $this->language->get('entry_sort_order');
		

		////////////////////////////////////
		// Добавленные данные
		////////////////////////////////////
		$data['module_label'] = $this->language->get('module_label'); 
		$data['module_table_header'] = $this->language->get('module_table_header'); 

		// Кнопки		
		$data['module_button'] = $this->language->get('module_button');

 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		////////////////////////////////////
		// Строим хлебные крошки
		////////////////////////////////////
  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_module'),
			'href'      => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);
		
   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('module/IMReport', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);
		
		////////////////////////////////////
		// Формируем ссылки
		////////////////////////////////////

		$data['report_links'] = array();

		$data['report_links']['top_product'] 
			= $this->url->link('module/IMReport/topProduct', 'token=' . $this->session->data['token'], 'SSL');

		$data['report_links']['client_group'] 
			= $this->url->link('module/IMReport/clientGroup', 'token=' . $this->session->data['token'], 'SSL');

		$data['report_links']['ship_region'] 
			= $this->url->link('module/IMReport/shipRegion', 'token=' . $this->session->data['token'], 'SSL');

		$data['report_links']['man_product'] 
			= $this->url->link('module/IMReport/manProduct', 'token=' . $this->session->data['token'], 'SSL');

		$data['report_links']['order_sales'] 
			= $this->url->link('module/IMReport/orderSales', 'token=' . $this->session->data['token'], 'SSL');

		// 1.5
		$data['report_links']['client_orders'] 
			= $this->url->link('module/IMReport/clientOrders', 'token=' . $this->session->data['token'], 'SSL');

		// 1.5
		$data['report_links']['option_sales'] 
			= $this->url->link('module/IMReport/optionSales', 'token=' . $this->session->data['token'], 'SSL');

		// 1.5
		if (VERSION >= '2.1')
		{
			$data['report_links']['link_to_client'] 
				= $this->url->link('customer/customer/edit', 'token=' . $this->session->data['token'], 'SSL');
		}
		// Для 2.0.3.1
		else
		{
			$data['report_links']['link_to_client'] 
				= $this->url->link('sale/customer/edit', 'token=' . $this->session->data['token'], 'SSL');
		}

		// 1.5 
		$data['report_links']['link_to_order'] 
			= $this->url->link('sale/order/info', 'token=' . $this->session->data['token'], 'SSL');

		$data['report_links']['cancel'] 
			= $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

		$data['report_links']['link_to_product'] 
			= $this->url->link('catalog/product/edit', 'token=' . $this->session->data['token'], 'SSL');

		$data['report_links']['link_to_category'] 
			= $this->url->link('catalog/category/edit', 'token=' . $this->session->data['token'], 'SSL');

		$data['modules'] = array();
		
		////////////////////////////////////
		// Стандартная подгрузка данных и вывод на шаблон
		////////////////////////////////////
		if (isset($this->request->post['IMReport_module'])) {
			$data['modules'] = $this->request->post['IMReport_module'];
		} elseif ($this->config->get('IMReport_module')) { 
			$data['modules'] = $this->config->get('IMReport_module');
		}	
		
		$this->load->model('design/layout');
		
		$data['layouts'] = $this->model_design_layout->getLayouts();

		$template = 'module/IMReport.tpl';
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		setcookie('token', $this->session->data['token']);
		
		$this->getForm($data);

		// 1.5 
		$data['client_orders_view'] = $this->load->controller('module/IMReport/clientOrdersView', $data);

		// 1.5
		$data['option_sales_view'] = $this->load->controller('module/IMReport/optionSalesView', $data);


		$this->response->setOutput($this->load->view($template, $data));
	}

	// 1.5
	////////////////////////////////////////////
	// Клиенты
	////////////////////////////////////////////
	// Вьюха по клиентам
	public function clientOrdersView($data = array())
	{
		//$this->template = 'module/IMReport_client.tpl';
		//$this->response->setOutput($this->render ());
		
		return $this->load->view('module/IMReport_client.tpl', $data);
	}

	// 1.5
	////////////////////////////////////////////
	// Опции
	////////////////////////////////////////////
	// Вьюха по опциям
	public function optionSalesView($data = array())
	{
		//$this->data = array_merge($this->data, $data);
		//$this->template = 'module/IMReport_option.tpl';
		//$this->response->setOutput($this->render ());
		return $this->load->view('module/IMReport_option.tpl', $data);
	}
	
	// Функция подгрузки списка языков и списка категорий
	private function getForm(&$data) {
		$this->load->model('localisation/language');
		$data['languages'] = $this->model_localisation_language->getLanguages();
		$data['token'] = $this->session->data['token'];

		$this->load->model('module/IMReport');

		// Загружаем категории
		$categories = $this->model_module_IMReport->getCategories(0);
		$firstItem = array();
		$firstItem[] = array(
			'id' => -1,
			'name' => 'Все категории',
			'status' => 1,
			'sort_order' => -1
		); 
		$categories = array_merge($firstItem, $categories);

		$data['list_cat'] = $categories;

		// Загружаем производителей
		$manufacturers = $this->model_module_IMReport->getManufacturer();
		$data['list_manufact'] = $manufacturers;

		// 1.5
		// Загружаем список режимов для отчета по клиентам
		$clientModes = array();
		$clientModes[] = array( 'id' => '0', 'name' => 'Стандартный' );
		$clientModes[] = array( 'id' => '1', 'name' => 'Поиск только зарегистрированных (без покупок)' );
		$clientModes[] = array( 'id' => '2', 'name' => 'Поиск утерянных клиентов' );
		$data['list_client_orders_modes'] = $clientModes;

		// Загружаем сортироку
		$data['list_top_sort'] = $this->model_module_IMReport->getSortList('top');
		$data['list_client_sort'] = $this->model_module_IMReport->getSortList('client');
		$data['list_ship_region_sort'] = $this->model_module_IMReport->getSortList('ship_region');
		$data['list_man_product_sort'] = $this->model_module_IMReport->getSortList('man_product');
		// 1.5
		$data['list_client_orders_sort'] = $this->model_module_IMReport->getSortList('client_orders');
		$data['list_option_sales_sort'] = $this->model_module_IMReport->getSortList('option_sales');
		
		// Загружаем текущий язык и статусы
		$language_id = $this->getCurrentLanguageId($data);
		
		$data['language_id'] = $language_id;
		$data['list_order_status'] = $this->model_module_IMReport->getOrderStatus($language_id);
	}

	// 1.5
	// Получение данных по клиентам
	public function clientOrders() {
		$this->load->model('module/IMReport');
		$json = array();
		$json['data'] = $this->model_module_IMReport->clientOrders($this->request->post['IMReport']);
		// CSV or JSON		
		$this->formResponse($json, $this->request->post['IMReport']);
	}

	// 1.5
	// Получение данных по опциям
	public function optionSales() {
		$this->load->model('module/IMReport');
		$json = array();
		$json['data'] = $this->model_module_IMReport->optionSales($this->request->post['IMReport']);
		// CSV or JSON		
		$this->formResponse($json, $this->request->post['IMReport']);
	}
	
	// Получение ходового товара
	public function topProduct() {
		$this->load->model('module/IMReport');
		$json = array();
		$json['data'] = $this->model_module_IMReport->topProduct($this->request->post['IMReport']);
		// CSV or JSON		
		$this->formResponse($json, $this->request->post['IMReport']);
	}
	
	// Получение группы клиентов
	public function clientGroup() {
		$this->load->model('module/IMReport');
		
		$json = array();
		$json['data'] = $this->model_module_IMReport->clientGroup($this->request->post['IMReport']);
		
		// CSV or JSON		
		$this->formResponse($json, $this->request->post['IMReport']);
	}
	
	// Доставка по регионам
	public function shipRegion() {
		$this->load->model('module/IMReport');
		
		$json = array();
		$json['data'] = $this->model_module_IMReport->shipRegion($this->request->post['IMReport']);
		
		// CSV or JSON		
		$this->formResponse($json, $this->request->post['IMReport']);
	}

	// Произодители (объем продуктов)
	public function manProduct() {
		$this->load->model('module/IMReport');
		
		$json = array();
		$json['data'] = $this->model_module_IMReport->manProduct($this->request->post['IMReport']);
		
		// CSV or JSON		
		$this->formResponse($json, $this->request->post['IMReport']);
	}

	// Оборот заказов
	public function orderSales() {
		$this->load->model('module/IMReport');
		
		$json = array();
		$json['data'] = $this->model_module_IMReport->orderSales($this->request->post['IMReport']);
		
		// CSV or JSON		
		$this->formResponse($json, $this->request->post['IMReport']);
	}
	
	//////////////////////////////////
	// Дополнительные функции
	//////////////////////////////////
	
	protected function formResponse($json, $postModule)
	{
		$currency = $this->getCurrentCurrency();
		
		$json['currency_pattern'] 
			= $currency['symbol_left']
				. '[digit]'
			. $currency['symbol_right']
		;
		$json['success'] = 1;

		if (isset($postModule['is_csv']) && (''.$postModule['is_csv'] == '1')) {
			$this->formCSVNameAndHeader();
			$this->response->setOutput($this->getCSVFromData($json['data']));
		}
		else {
			$this->response->setOutput(json_encode($json));
		}
	}
	
	protected function formCSVNameAndHeader()
	{
		$price_export = date("Ymd-Hi").'_price_export.csv';
		
		$this->response->addheader('Pragma: public');
		$this->response->addheader('Expires: 0');
		$this->response->addheader('Content-Description: File Transfer');
		$this->response->addheader('Content-Type: application/octet-stream');
		$this->response->addheader('Content-Disposition: attachment; filename='.$price_export);
		$this->response->addheader('Content-Transfer-Encoding: binary');
	}
	
	// Формирование CSV из данных
	protected function getCSVFromData($data)
	{
		$output = '';
		$replace = array(';',"\n");
		$is_first_row = true;
		$headerOutput = '';
		
		// Проходимся по всем строчкам
		foreach($data as $row)
		{
			$is_first_cell = true;
			
			// Проходимся по всем ячейкам
			foreach($row as $key => $item)
			{
				if ($is_first_cell)
				{
					$is_first_cell = false;
					if ($is_first_row)	
					{
						$headerOutput .= str_replace($replace, '', '' . $key);
					}
					$output .= str_replace($replace, '', '' . $item);
				}
				else
				{
					if ($is_first_row)	
					{
						$headerOutput .= ';' . str_replace($replace, '', '' . $key);
					}
					$output .= ';' . str_replace($replace, '', '' . $item);
				}
			}
			
			$is_first_row = false;
			
			$output .= "\n";
		}
		
		return iconv('UTF-8', 'cp1251', $headerOutput . "\n" . $output);
	}
	
	// Получение текущего языка
	protected function getCurrentLanguageId($data)
	{
		// Загружаем текущий язык и статусы
		$langs_temp = reset($data['languages']);
		$language_id = $langs_temp['language_id'];
		
		// OC 2.2 :(
		$langs_temp = $this->config->get('config_admin_language');
		if (isset($langs_temp) && !empty($langs_temp))
		{
			$language_id = $data['languages'][$this->config->get('config_admin_language')]['language_id'];
		}

		// OC 2.2 :(
		$langs_temp = $this->language->get('code');
		if (isset($langs_temp) && !empty($langs_temp))
		{
			if (isset($data['languages'][$this->language->get('code')]))
			{
				$language_id = $data['languages'][$this->language->get('code')]['language_id'];
			}
		}
		
		if (isset($this->session->data['language']))
		{
			$language_id = $data['languages'][$this->session->data['language']]['language_id'];
		}

		return $language_id;		
	}
	
	// Получение текущей валюты
	protected function getCurrentCurrency()
	{
		$this->load->model('localisation/currency');
		$currencies = $this->model_localisation_currency->getCurrencies();

		if (method_exists($this->currency, 'getCode')){
			$currency = $currencies[$this->currency->getCode()];
		}
		// OC 2.2 :(
		else {
			$currency = reset($currencies);
			
			$temp_curr = $this->config->get('config_currency');
			if (isset($temp_curr) && !empty($temp_curr))
			{
				$currency = $currencies[$this->config->get('config_currency')];
			}
			
			//$temp_curr = $this->session->data['currency'];
			if (isset($this->session->data['currency']) && !empty($this->session->data['currency']))
			{
				$currency = $currencies[$this->session->data['currency']];
			}
			
		}	
		
		return $currency;
	}
	
	//////////////////////////////////
	// Установка и удаление
	//////////////////////////////////

	/////////////////////////////////////////
	// Вспомогательные функции
	/////////////////////////////////////////

	// Добавление кода
	protected function addPHPCode($path, $sign, $searchcode, $addCode, $addCodeAfter = true)
	{
		$content = file_get_contents($path);
		$content = str_replace(
			$searchcode, 
			($addCodeAfter ? $searchcode : '')
			. '/* ' . $sign . ' Start */'
				.$addCode
			. '/* ' . $sign . ' End */'
			. (!$addCodeAfter ? $searchcode : ''), 
			$content
		);

		$fp = fopen($path, 'w+');
		fwrite($fp, $content);
		fclose($fp);
	}
	
	// Удаление кода
	protected function removePHPCode($path, $sign)
	{
		$content = file_get_contents($path);

		preg_match_all('!(\/\*)\s?' . $sign . ' Start.+?' . $sign . ' End\s+?(\*\/)!is', $content, $matches);
		foreach ($matches[0] as $match) {
			$content = str_replace($match, '', $content);
		}

		$fp = fopen($path, 'w+');
		fwrite($fp, $content);
		fclose($fp);
	}

	// Добавление кода
	protected function addHTMLCode($path, $sign, $searchcode, $addCode, $addCodeAfter = true)
	{
		$content = file_get_contents($path);
		$content = str_replace(
			$searchcode, 
			($addCodeAfter ? $searchcode : '')
			. '<!-- ' . $sign . ' Start -->'
				.$addCode
			. '<!-- ' . $sign . ' End -->'
			. (!$addCodeAfter ? $searchcode : ''), 
			$content
		);

		$fp = fopen($path, 'w+');
		fwrite($fp, $content);
		fclose($fp);
	}
	
	// Удаление кода
	protected function removeHTMLCode($path, $sign)
	{
		$content = file_get_contents($path);

		preg_match_all('!(\<\!\-\-)\s?' . $sign . ' Start.+?' . $sign . ' End\s+?(\-\-\>)!is', $content, $matches);
		foreach ($matches[0] as $match) {
			$content = str_replace($match, '', $content);
		}

		$fp = fopen($path, 'w+');
		fwrite($fp, $content);
		fclose($fp);
	}
	
	// Установка модуля
	public function install() {
        $this->load->model('module/IMReport');
		$this->model_module_IMReport->install();
		
		// Указываем, что модуль установлен
		$this->load->model('setting/setting');

		if (version_compare('2.2', VERSION) <= 0) {
	        // Добавляем код в php menu
			$this->addPHPCode(
				DIR_APPLICATION . 'controller/common/menu.php',
				'IMReport',
				'$data[\'zone\'] = $this->url->link(\'localisation/zone\', \'token=\' . $this->session->data[\'token\'], true);',
				' $data[\'module_imreport\'] = $this->url->link(\'module/IMReport\', \'token=\' . $this->session->data[\'token\'], \'SSL\'); '
			);
		}
		else {
	        // Добавляем код в php menu
			$this->addPHPCode(
				DIR_APPLICATION . 'controller/common/menu.php',
				'IMReport',
				'$data[\'zone\'] = $this->url->link(\'localisation/zone\', \'token=\' . $this->session->data[\'token\'], \'SSL\');',
				' $data[\'module_imreport\'] = $this->url->link(\'module/IMReport\', \'token=\' . $this->session->data[\'token\'], \'SSL\'); '
			);
        }
        
        // Добавляем код в tpl menu
        $this->addHTMLCode(
        	DIR_APPLICATION . 'view/template/common/menu.tpl', 
        	'IMReport',
        	'<li id="reports"><a class="parent"><i class="fa fa-bar-chart-o fa-fw"></i> <span><?php echo $text_reports; ?></span></a>',
        	'<li id="module_imreport"><a href="<?php echo $module_imreport; ?>"><i class="fa fa-bar-chart-o fa-fw"></i> <span>IMReport</span></a></li>',
        	false
        );
        
        // Перенаправляем на главную страницу
		$this->response->redirect(HTTPS_SERVER . 'index.php?route=extension/module&token=' . $this->session->data['token']);
	}
	
	// Деинсталляция модуля
    public function uninstall() {
        $this->load->model('module/IMReport');
		$this->model_module_IMReport->uninstall();
		
		// Указываем, что модуль удален
	 	$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('IMReport', array('IMReport_status'=>0));

		// Удаляем код
		$this->removePHPCode(
			DIR_APPLICATION . 'controller/common/menu.php',
			'IMReport'
		);

		// Удаляем код
		$this->removeHTMLCode(
        	DIR_APPLICATION . 'view/template/common/menu.tpl', 
        	'IMReport'
		);
        
        // Перенаправляем на главную страницу
		$this->response->redirect(HTTPS_SERVER . 'index.php?route=extension/module&token=' . $this->session->data['token']);
    
    }
	
	// Проверка, что у пользователя есть необходимые права
	private function validate() {
		if (!$this->user->hasPermission('modify', 'module/IMReport')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if (!$this->error) {
			return true;
		} else {
			return false;
		}	
	}
}
