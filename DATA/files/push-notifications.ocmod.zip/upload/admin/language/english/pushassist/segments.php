<?php
// Heading 
$_['heading_title'] = 'Segment Details';
$_['create_heading_title'] = 'Create Segment';
// Text
$_['text_total']= 'Total';
$_['text_segment_name']= 'Segment Name';
$_['text_subscribers_count']= 'Subscribers Count';
$_['text_created_date']= 'Created Date';
$_['text_success']= 'You have successfully!';
$_['text_new_title']= 'Create Segment';
$_['text_segment_name']= 'Segment Name';
$_['text_segment_message']= 'Limit 40 Characters. E.g. Google';
$_['text_send']= 'Create Segment';



// Error
$_['error_warning']                    = 'Warning: Please check the form carefully for errors!';
$_['error_permission'] 			= 'Warning: You do not have permission to modify!';
?>