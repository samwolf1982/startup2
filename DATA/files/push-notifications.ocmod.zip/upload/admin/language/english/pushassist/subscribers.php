<?php
// Heading 
$_['heading_title']     		= 'Subscribers details';

// Text
$_['text_site_url']= 'SITE URL';
$_['text_chrome']= 'CHROME';
$_['text_firefox']= 'FIREFOX';
$_['text_safari']= 'SAFARI';
$_['text_success']= 'You have successfully';

// Error
$_['error_warning']                    = 'Warning: Please check the form carefully for errors!';
$_['error_permission'] 			= 'Warning: You do not have permission to modify !';
?>