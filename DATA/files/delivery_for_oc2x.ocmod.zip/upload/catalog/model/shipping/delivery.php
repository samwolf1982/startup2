<?php
class ModelShippingDelivery extends Model
{
    private $cost = 0.00;

    public function __construct($registry)
    {          
        require_once(DIR_SYSTEM . 'library/shippingDelivery.php');
        $registry->set('shipping_delivery', new ShippingDelivery($registry));
          
        parent::__construct($registry);     
    }
    
    public function getQuote($address)
    {
        $this->load->language('shipping/delivery');

        // массив для записи цен доставки для каждого города = массив для вывода отделений = вывод модуля доставки
        $cities_ids = $method_data = $quote_data = array();

        // Проверка на включенность модуля симплы
        $warehouse_name    = (isset($address['delivery_warehouses'])) ? $address['delivery_warehouses'] : false;
        $warehouse_city_id = (isset($address['delivery_hidden_city_id'])) ? $address['delivery_hidden_city_id'] : false;
        $warehouse_id      = (isset($address['delivery_hidden_warehouse_id'])) ? $address['delivery_hidden_warehouse_id'] : false;

        $module_simple_checkout_status = ($warehouse_name !== false && $warehouse_city_id !== false && $warehouse_id !== false && $this->config->get('delivery_simple_module_status')) ? 1 : 0;

        // Проверяем включен ли модуль (его статус)
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int) $this->config->get('delivery_geo_zone_id') . "' AND country_id = '" . (int) $address['country_id'] . "' AND (zone_id = '" . (int) $address['zone_id'] . "' OR zone_id = '0')");

        if (!$this->config->get('delivery_geo_zone_id')
            || $this->config->get('delivery_status')
            || $query->num_rows
        ) {
            $status = true;
        } else {
            $status = false;
        }

        // Если модуль включен, выполняем поиск складов расчет стоимости достовки
        if ($status) {
            // Дефолтные параметры для доставки
            $delivery_parameters = array(
                "culture"           => "ru-RU",
                "areasSendId"       => $this->config->get('delivery_base_warehouse_city_id'), // Город отправления
                "areasResiveId"     => "", // Город прибытия
                "warehouseSendId"   => $this->config->get('delivery_base_warehouse_id'), // ID склада отправления
                "warehouseResiveId" => "", // ID склада прибытия
                "InsuranceValue"    => ($this->config->get('delivery_additional_settings_calculate_insurance_value')) ? $this->cart->getTotal() : 0.00, // Учитывать застрахованную стоимость груза
                "deliveryScheme"    => 2, // Схема доставки
            );

            // Перебираем параметры продуктов и учитываем их при расчете доставки
            $delivery_parameters['category'] = $this->getProductsProperties();

            if ($this->config->get('delivery_free_shipping')) {
                $free_shipping_text = "<b>Бесплатно</b>";
                $this->cost         = 0.00;
            }

            // Если модуль используется в Simple Checkout
            // Тогда выполняем расчет только по выбранному складу
            if ($module_simple_checkout_status) {
                $delivery_parameters['areasResiveId']     = $warehouse_city_id;
                $delivery_parameters['warehouseResiveId'] = $warehouse_id;

                $result = $this->shipping_delivery->calculateShippingCost($delivery_parameters);

                $this->cost = (isset($result->data->allSumma) && $result->data->allSumma != null) ? $result->data->allSumma : 0.00;

                $quote_data['delivery'] = array(
                    'code'         => 'delivery.delivery',
                    'title'        => $this->language->get('text_description'),
                    'cost'         => $this->cost,
                    'tax_class_id' => 0,
                    'text'         => isset($free_shipping_text) ? $free_shipping_text : $this->setCurrencyFormat($this->cost),
                );
            } elseif (mb_strlen($address['city']) > 2) {
                // Если выполняется расчет на обычной странице Checkout
                // И длина названия города более 2-х символов
                $warehouses = $this->shipping_delivery->getWarehousesByCityName($address['city']);

                foreach ($warehouses as $key => $warehouse) {
                    // Формируем вывод надписи для каждого склада
                    $warehouse_title = "<b>" . $warehouse['name'] . "</b> (" . $warehouse['address'] . ")";
                    $warehouse_title .= '<a role="button" data-html="true" data-toggle="tooltip" data-placement="top" title="" ';
                    $warehouse_title .= ' data-original-title="<b>Телефон:</b> ' . $warehouse['phone'] . "<br><b>Время работы:</b> " . $warehouse['operating_time'] . '">';
                    $warehouse_title .= ' <i class="fa fa-question-circle"></i></a>';

                    // Рассчитываем стоимость доставки для каждого отделения
                    $delivery_parameters['areasResiveId']     = $warehouse['city_id'];
                    $delivery_parameters['warehouseResiveId'] = $warehouse['warehouse_id'];

                    // Если цена уже была найдена ранее,
                    // Игнорируем запрос на получение цены в том же городе
                    if (!in_array($warehouse['city_id'], $cities_ids)) {
                        $result = $this->shipping_delivery->calculateShippingCost($delivery_parameters);

                        $this->cost = ($result->data->allSumma != null) ? $result->data->allSumma : 0.00;

                        // Записываем город в массив городов, по которым уже получены цены
                        $cities_ids[] = $warehouse['city_id'];
                    }

                    $quote_data['delivery' . $key] = array(
                        'code'         => 'delivery.delivery' . $key,
                        'title'        => $warehouse_title,
                        'cost'         => $this->cost,
                        'tax_class_id' => 0,
                        'text'         => isset($free_shipping_text) ? $free_shipping_text : "<b>" . $this->setCurrencyFormat($this->cost) . "</b>", // 0.00
                    );
                }
            }

            if (!empty($quote_data)) {
                $method_data = array(
                    'code'       => 'delivery',
                    'title'      => $this->language->get('text_title'),
                    'quote'      => $quote_data,
                    'sort_order' => $this->config->get('delivery_sort_order'),
                    'error'      => false,
                );
            }
        }

        return $method_data;
    }

    // Добавляем товары в корзине для учета их при расчете доставки
    private function getProductsProperties()
    {
        $products_for_delivery = array();

        $products = $this->cart->getProducts();

        foreach ($products as $product) {
            $quantity           = (int) $product['quantity'];
            $product_properties = array(
                "categoryId" => "00000000-0000-0000-0000-000000000000", //Id категории груза
                "countPlace" => $quantity, // 1,
            );

            // Учет веса при расчете стоимости доставки
            if ($this->config->get('delivery_additional_settings_calculate_weight')) {
                $label_weight = trim(mb_strtolower($this->weight->getUnit($product['weight_class_id'])));

                if ($label_weight == "kg"
                    or $label_weight == "kg."
                    or $label_weight == "кг"
                    or $label_weight == "кг."
                ) {
                    $product_properties['helf'] = number_format($product['weight'], 6) * $quantity;
                } elseif ($label_weight == "g"
                    or $label_weight == "g."
                    or $label_weight == "г"
                    or $label_weight == "г."
                ) {
                    $product_properties['helf'] = number_format(($product['weight'] / 1000), 6) * $quantity;
                } else {
                    $product_properties['helf'] = 0.01 * $quantity;
                }
            }

            // Учитываем объем
            if ($this->config->get('delivery_additional_settings_calculate_volume')) {
                $label_length = trim(mb_strtolower($this->length->getUnit($product['length_class_id'])));

                if ($label_length == "cm"
                    or $label_length == "cm."
                    or $label_length == "см"
                    or $label_length == "см."
                ) {
                    $product_properties['size'] = number_format((($product['length'] * $product['height'] * $product['width']) / (100 * 100 * 100)) * $quantity, 6);
                } else if ($label_length == "m"
                    or $label_length == "m."
                    or $label_length == "метр"
                    or $label_length == "м."
                ) {
                    $product_properties['size'] = number_format($product['length'] * $product['height'] * $product['width'] * $quantity, 6);
                } else {
                    $product_properties['size'] = 0.01 * $quantity;
                }
            }

            $products_for_delivery[] = $product_properties;
        }

        return $products_for_delivery;
    }

    public function setCurrencyFormat($val)
    {
        if (version_compare(VERSION, '2.2.0.0', '>=')) {
            return $this->currency->format($val, $this->session->data['currency']);
        } else {
            return $this->currency->format($val);
        }
    }

}
