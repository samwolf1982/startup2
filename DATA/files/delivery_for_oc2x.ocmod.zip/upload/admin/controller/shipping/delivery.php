<?php
/*
  *******************************************************************************
  *  Module: Shipping method "Delivery"
  *  
  *  Web-site: http://opencart-modules.com
  *  Email: dev.dashko@gmail.com
  *  © Leonid Dashko
  *
  *  Below source-code or any part of the source-code cannot be resold or distributed.
  ******************************************************************************
*/

class ControllerShippingdelivery extends Controller
{
    private $errors = array();

    public function __construct($registry)
    {
        require_once DIR_SYSTEM . 'library/shippingDelivery.php';
        $registry->set('shipping_delivery', new ShippingDelivery($registry));

        parent::__construct($registry);

        $this->load->language('shipping/delivery');

        $this->load->model('setting/setting');
    }

    public function install()
    {
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "shipping_delivery_cities` (
              `city_id` varchar(36) NOT NULL,
              `name` varchar(75) NOT NULL,
              `region_id` varchar(36) NOT NULL,
              `is_warehouse` int(1) NOT NULL COMMENT '\"0 - no, 1 - yes\"',
              PRIMARY KEY (`city_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;"
        );
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "shipping_delivery_warehouses` (
              `warehouse_id` varchar(36) NOT NULL,
              `name` varchar(75) NOT NULL,
              `address` varchar(100) DEFAULT NULL,
              `city_id` varchar(36) NOT NULL,
              `operating_time` varchar(50) DEFAULT NULL,
              `phone` varchar(15) DEFAULT NULL,
              `latitude` float(13,10) DEFAULT NULL,
              `longitude` float(13,10) DEFAULT NULL,
              PRIMARY KEY (`warehouse_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;"
        );
    }

    public function index()
    {
        $this->document->setTitle($this->language->get('heading_title'));

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('delivery', $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('shipping/delivery', 'token=' . $this->session->data['token'], 'SSL'));
        }

        $data['heading_title'] = $this->language->get('heading_title');

        $data['text_edit']      = $this->language->get('text_edit');
        $data['text_enabled']   = $this->language->get('text_enabled');
        $data['text_disabled']  = $this->language->get('text_disabled');
        $data['text_all_zones'] = $this->language->get('text_all_zones');
        $data['text_none']      = $this->language->get('text_none');

        $data['entry_geo_zone']   = $this->language->get('entry_geo_zone');
        $data['entry_status']     = $this->language->get('entry_status');
        $data['entry_sort_order'] = $this->language->get('entry_sort_order');

        $data['button_save']                         = $this->language->get('button_save');
        $data['button_cancel']                       = $this->language->get('button_cancel');
        $data['button_update_warehouses_and_cities'] = $this->language->get('button_update_warehouses_and_cities');

        // Show success msg
        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        // Show errors msg
        if (!empty($this->errors)) {
            $this->session->data['errors'] = $this->errors;
        }

        if (isset($this->session->data['errors'])) {
            $data['errors'] = $this->session->data['errors'];
            unset($this->session->data['errors']);
        } else {
            $data['errors'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL'),
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_shipping'),
            'href' => $this->url->link('extension/shipping', 'token=' . $this->session->data['token'], 'SSL'),
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('shipping/delivery', 'token=' . $this->session->data['token'], 'SSL'),
        );

        $data['action'] = $this->url->link('shipping/delivery', 'token=' . $this->session->data['token'], 'SSL');
        $data['cancel'] = $this->url->link('extension/shipping', 'token=' . $this->session->data['token'], 'SSL');

        $data['link_to_support'] = 'http://opencart-modules.com/tab-modules?lang=' . trim($this->config->get('config_admin_language'));

        if (isset($this->request->post['delivery_base_warehouse_name'])) {
            $data['delivery_base_warehouse_name'] = $this->request->post['delivery_base_warehouse_name'];
        } else {
            $data['delivery_base_warehouse_name'] = $this->config->get('delivery_base_warehouse_name');
        }

        if (isset($this->request->post['delivery_base_warehouse_id'])) {
            $data['delivery_base_warehouse_id'] = $this->request->post['delivery_base_warehouse_id'];
        } else {
            $data['delivery_base_warehouse_id'] = $this->config->get('delivery_base_warehouse_id');
        }

        if (isset($this->request->post['delivery_base_warehouse_city_id'])) {
            $data['delivery_base_warehouse_city_id'] = $this->request->post['delivery_base_warehouse_city_id'];
        } else {
            $data['delivery_base_warehouse_city_id'] = $this->config->get('delivery_base_warehouse_city_id');
        }

        if (isset($this->request->post['delivery_geo_zone_id'])) {
            $data['delivery_geo_zone_id'] = $this->request->post['delivery_geo_zone_id'];
        } else {
            $data['delivery_geo_zone_id'] = $this->config->get('delivery_geo_zone_id');
        }

        if (isset($this->request->post['delivery_simple_module_status'])) {
            $data['delivery_simple_module_status'] = $this->request->post['delivery_simple_module_status'];
        } else {
            $data['delivery_simple_module_status'] = $this->config->get('delivery_simple_module_status');
        }

        $this->load->model('localisation/geo_zone');

        $data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

        if (isset($this->request->post['delivery_status'])) {
            $data['delivery_status'] = $this->request->post['delivery_status'];
        } else {
            $data['delivery_status'] = $this->config->get('delivery_status');
        }

        if (isset($this->request->post['delivery_sort_order'])) {
            $data['delivery_sort_order'] = $this->request->post['delivery_sort_order'];
        } else {
            $data['delivery_sort_order'] = $this->config->get('delivery_sort_order');
        }

        if (isset($this->request->post['delivery_free_shipping'])) {
            $data['delivery_free_shipping'] = $this->request->post['delivery_free_shipping'];
        } else {
            $data['delivery_free_shipping'] = $this->config->get('delivery_free_shipping');
        }

        $data['text'] = array(
            'general_settings'     => $this->language->get('general_settings'),
            'additional_settings'  => $this->language->get('additional_settings'),
            'update_warehouses'    => $this->language->get('update_warehouses'),
            'warehouses_locations' => $this->language->get('warehouses_locations'),
            'support'              => $this->language->get('support'),
        );

        $data['header']      = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer']      = $this->load->controller('common/footer');

        $data['cities']          = $this->shipping_delivery->getCities();
        $data['warehousesForJS'] = $this->shipping_delivery->getAllWarehousesForJS();

        $data['additional_settings'] = $this->model_setting_setting->getSetting('delivery_additional_settings');

        $data['token'] = $this->session->data['token'];

        $db_last_update = $this->model_setting_setting->getSetting('delivery_db');
        if (isset($db_last_update['delivery_db_last_update'])) {
            $data['db_last_update'] = $db_last_update['delivery_db_last_update'];
        } else {
            $data['db_last_update'] = "";
        }

        $this->response->setOutput($this->load->view('shipping/delivery.tpl', $data));
    }

    // Обновление базы городов
    public function ajax_update_cities()
    {
        $data           = array();
        $data['errors'] = array();

        if (!$this->validate()) {
            $data['errors'][] = $this->language->get('error_permission');
        } else {
            $result = $this->shipping_delivery->updateCities();

            if (isset($result['error'])) {
                $data['result'] = $result['error'];
            } else {
                $data['result'] = $result['success'];
            }

        }

        $this->response->setOutput(json_encode($data));
    }

    // Обновление базы складов
    public function ajax_update_warehouses()
    {
        $data           = array();
        $data['errors'] = array();

        if (!$this->validate()) {
            $data['errors'][] = $this->language->get('error_permission');
        } else {
            $result = false;

            // Ограничивыем время выполнение скрипта до 180 seconds = 3 minutes
            // И засекаем время выполнения скрипта
            ini_set('max_execution_time', 180);

            $time_start = microtime(true);
            $result     = $this->shipping_delivery->updateWarehouses();
            $time_end   = microtime(true);

            $execution_time = ($time_end - $time_start) / 60;
            $execution_time = '<b>Время выполнения:</b> ' . substr($execution_time, 0, 4) . ' мин.';

            if ($result) {
                $this->model_setting_setting->editSetting('delivery_db', array("delivery_db_last_update" => date("d/m/Y")));
                $data['last_date_db_update'] = date("d/m/Y");

                $data['result'] = "Склады успешно обновлены. " . $execution_time;
            } else {
                $data['result'] = "Ошибка обновления складов. ";
            }
        }

        $this->response->setOutput(json_encode($data));
    }

    // Сохраняем дополнительные настройки модуля
    public function ajax_save_additional_settings()
    {
        $result = '';

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('delivery_additional_settings', $this->request->post);

            $result = "<p style=\"color: #00B600;font-size: 19px;\">Дополнительные настройки успешно сохранены</p>";
        } else {
            $result = "Ошибка сохранения данных";
        }

        $this->response->setOutput(json_encode($result));
    }

    protected function validate()
    {
        if (!$this->user->hasPermission('modify', 'shipping/delivery')) {
            $this->errors[] = $this->language->get('error_permission');
        }

        return !$this->errors;
    }
}
