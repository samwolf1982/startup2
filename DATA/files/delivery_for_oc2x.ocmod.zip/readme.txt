﻿
Установка:
1. Загружаем файлы из папки "upload" в корень вашего сайта.

2. Переходим в меню в Модули -> Доставка -> Доставка курьерской службой "Деливери" -> Включить

3. Переходим во вкладку "Обновление отделений", после чего обновляем отделения.

4. После обновления складов обновляем страницу. Включаем статус модуля на "Включено" и заполняем "склад отправления" в настройках доставки. Сохраняемся.


*************** Если Вы используете модуль Simple Checkout ***************
5. Ставим галочку "На странице оформления заказа используется модуль Simple Checkout?" в настройках доставки "Деливери"

6. Переходим в меню в Модули -> Простая регистрация и заказ Simple -> Вкладка "Поля"
  - Создаем поле (слева) с названием идентификатора "delivery_warehouses"
	* Название для поля - "Отделение Delivery" (либо другое)
	* Отмечаем что это поле является полем объекта "АДРЕС"
	* Тип поля "text"
	* Заполняем поле "Плейсхолдер" - "Введите название города" (либо другое)
	* Ставим галочку в поле "Сохранять значение поля в комментарий к заказу"
	
  - Создаем поле (слева) с названием идентификатора "delivery_hidden_warehouse_id"
	* Отмечаем что это поле является полем объекта "АДРЕС"
	* Тип поля "text"
	* Ставим галочку в поле "Может ли изменение поля влиять на методы достави, оплаты или на итоговую сумму заказа?"
	* Переходим во вкладку "Правила проверки" -> Отмечаем, что поле не может быть пустым. В текст ошибки вписываем "Не выбран склад Delivery!" (либо другое)
	
  - Создаем поле (слева) с названием идентификатора "delivery_hidden_city_id"
	* Отмечаем что это поле является полем объекта "АДРЕС"
	* Тип поля "text"

7. Возвращаемся в настройки модуля "Простая регистрация и заказ Simple" -> Переходим во вкладку "Страницы" -> "Заказ" -> "Адрес доставки" - Выбираем метод доставки "Отправка службой "Деливери" за счет покупателя". Добавляем туда поля:
	- Отделение Delivery
	- delivery_hidden_warehouse_id (Отмечаем его в графе "Обязательное?" - "Обязательное всегда")
	- delivery_hidden_city_id

8. Последний ШАГ. 
    - Возвращаемся в настройки модуля "Простая регистрация и заказ Simple" -> Переходим во вкладку "Интеграция" -> "Джаваскрипты".
	- В поле "Этот джаваскрипт будет выполнен после каждой ajax перезагрузки" добавляем следующий код:

/* Delivery shipping script start */
/* Для скрытых ячеек - доставка Delivery */
$('#shipping_address_delivery_hidden_warehouse_id, #shipping_address_delivery_hidden_city_id').hide()

var div_to_hide_warehouse_id = $("#shipping_address_delivery_hidden_warehouse_id").parent().parent(),
    div_to_hide_city_id = $("#shipping_address_delivery_hidden_city_id").parent().parent(),
    div_text_error_to_hide = div_to_hide_warehouse_id.find(".simplecheckout-rule-group");

div_to_hide_warehouse_id.find('label').remove();
div_to_hide_warehouse_id.find('td').first().remove();

div_to_hide_city_id.find('label').remove();
div_to_hide_city_id.find('td').first().remove();

div_to_hide_city_id.hide();

div_text_error_to_hide.find('div').css("text-align", "right");

$("#shipping_address_delivery_warehouses").on('change', function() {
    $("#shipping_address_delivery_hidden_warehouse_id").val('');
    $("#shipping_address_delivery_hidden_city_id").val('');
});

$("#shipping_address_delivery_warehouses")
    .after('<div id="autocomplete-city-for-delivery" style="position:relative;"></div>');

$( "#shipping_address_delivery_warehouses" ).autocomplete({
    minLength: 2,
    appendTo: "#autocomplete-city-for-delivery",
    source: function (request, response) {
      $.ajax({
          type: "GET",
          url: 'index.php?route=checkout/shipping_delivery/cities/&city_name=' +  encodeURIComponent(request),
          dataType: 'json',
          success: function(json) {
            response($.map( json, function( item ) {
                return {
                    label: item.name + " (" + item.address + ")",
                    value: item.warehouse_id,
                    city_id: item.city_id
                }
            }));
          }
      });
    },
    select: function(event) {
        $('#shipping_address_delivery_warehouses').val(event.label);
        $('#shipping_address_delivery_hidden_warehouse_id').val(event.value);
        $('#shipping_address_delivery_hidden_city_id').val(event.city_id);
        
        $( "#simplecheckout_button_cart" ).trigger( "click" );
        return false; // Prevent the widget from inserting the value.
    },
   focus: function(event, ui) {
        event.preventDefault();
   }
});
/* Delivery shipping script end */
