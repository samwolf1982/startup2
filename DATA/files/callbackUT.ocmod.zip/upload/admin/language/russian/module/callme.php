<?php

$_['heading_title'] 			= 'Callme © My2You';
$_['heading_title2'] 			= 'Callme';
$_['text_module']	 			= 'Модули';

$_['text_success']				= 'Настройки модуля обновлены!';
$_['text_edit']        				= 'Настройки модуля';


$_['entry_status']     = 'Статус';

$_['text_sender'] = 'Системное имя';
$_['text_showfieldtime'] = 'Показывать поле времени';
$_['text_link_page'] = 'Отправлять ссылку страницы на емайл';
$_['text_button_page'] = 'Кнопка на странице ';
$_['text_capcha'] = 'Капча';
$_['text_button_color'] = 'Цвет кнопки';
$_['text_white'] = 'Белый';
$_['text_green'] = 'Зеленый';
$_['text_black'] = 'Черный';
$_['text_pink'] = 'Розовый';
$_['text_blue'] = 'Светло-синий';
$_['text_yelow'] = 'Желтый';
$_['text_yes'] = 'Да';
$_['text_no'] = 'Нет';



?>