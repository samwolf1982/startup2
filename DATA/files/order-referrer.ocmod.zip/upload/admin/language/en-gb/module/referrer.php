<?php
// Heading
$_['heading_title']     = 'Order Referrer';

// Text
$_['text_success']      = 'Success: You have modified module Order Referrer!';
$_['text_edit']      = 'Edit';
$_['text_default']      = 'By default';
$_['text_module']	    = 'modules';
$_['text_name']	        = 'Name';
$_['text_url_mask']	    = 'URL Mask';
$_['text_url_param']	= 'URL Param';
$_['button_insert']      = 'Insert';

// Column
$_['column_name']       = 'Name';
$_['column_url_mask']   = 'URL Mask';
$_['column_url_param']  = 'URL Param';
$_['column_action']     = 'Action';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify module Order Referrer!';
?>