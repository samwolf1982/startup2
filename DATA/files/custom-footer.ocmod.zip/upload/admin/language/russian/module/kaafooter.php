<?php

$_['heading_title'] 			= 'Custom Footer';
$_['text_module']	 			= 'Модули';
$_['text_success']				= 'Настройки модуля обновлены!';

$_['text_1'] = 'Ссылка на Твиттер';
$_['text_2'] = 'Ссылка на Google';
$_['text_3'] = 'Ссылка на Facebook';
$_['text_4'] = 'Ссылка на Instagram';
$_['text_5'] = 'Ссылка на ВК';
$_['text_6'] = 'Ссылка на OK';
$_['text_size'] = 'Размер иконок в px (10-40)';
$_['text_cards'] = 'Способы оплаты';
$_['text_html'] = 'HTML Текст';


$_['text_mail'] = 'Адрес электронной почты';
$_['text_phone'] = 'Телефон';
$_['text_skype'] = 'Скайп';
$_['text_open'] = 'График работы';
$_['text_comment'] = 'Комментарий';
$_['text_address'] = 'Адрес';
