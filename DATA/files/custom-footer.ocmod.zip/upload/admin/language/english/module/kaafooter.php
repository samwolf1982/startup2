<?php

$_['heading_title'] = 'Footer OcTheme';
$_['text_module'] = 'Modules';
$_['text_success'] = 'module Settings updated!';

$_['text_1'] = 'Link to Twitter';
$_['text_2'] = 'Link to Google';
$_['text_3'] = 'Link to Facebook';
$_['text_4'] = 'Link to Instagram';
$_['text_5'] = 'Link to VK';
$_['text_6'] = 'Link to OK';
$_['text_size'] = 'Size px (10-40)';
$_['text_cards'] = 'Logo Cards';
$_['text_html'] = 'HTML Text';


$_['text_mail'] = 'E-Mail';
$_['text_phone'] = 'Telephone';
$_['text_skype'] = 'Skype';
$_['text_open'] = 'Opening Times';
$_['text_comment'] = 'Comment';
$_['text_address'] = 'Address';
