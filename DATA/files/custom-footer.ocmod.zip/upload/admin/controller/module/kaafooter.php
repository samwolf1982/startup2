<?php
class ControllerModulekaafooter extends Controller {
	private $error = array(); 

	public function index() {   
		$this->load->language('module/kaafooter');

		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');
		$kaafooter = $this->config->get('kaafooter');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {

			$this->model_setting_setting->editSetting('kaafooter', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));
		}

		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_1'] = $this->language->get('text_1');
		$data['text_2'] = $this->language->get('text_2');
		$data['text_3'] = $this->language->get('text_3');
		$data['text_4'] = $this->language->get('text_4');
		$data['text_5'] = $this->language->get('text_5');
		$data['text_6'] = $this->language->get('text_6');
		$data['text_size'] = $this->language->get('text_size');
		$data['text_cards'] = $this->language->get('text_cards');
		$data['text_html'] = $this->language->get('text_html');
		$data['text_html2'] = $this->language->get('text_html2');
		$data['text_mail'] = $this->language->get('text_mail');
		$data['text_phone'] = $this->language->get('text_phone');
		$data['text_skype'] = $this->language->get('text_skype');
		$data['text_open'] = $this->language->get('text_open');
		$data['text_comment'] = $this->language->get('text_comment');
		$data['text_address'] = $this->language->get('text_address');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_module'),
			'href'      => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('module/kaafooter', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);

		$data['action'] = $this->url->link('module/kaafooter', 'token=' . $this->session->data['token'], 'SSL');		
		$data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

		$kaafooter_data = array ('str1','str2', 'str3', 'str4', 'str5', 'str6', 'size', 'cards','html','html2','html4','html3', 'mail', 'phone', 'skype', 'open', 'comment','address');
		foreach ($kaafooter_data as $datas) {
			if (isset($this->request->post['kaafooter'][$datas])) {
				$data[$datas] = $this->request->post['kaafooter'][$datas];
			} else {
				$data[$datas] = $kaafooter[$datas];
			}
		}


		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('module/kaafooter.tpl', $data));
		
		
	}

	private function validate() {
		if (!$this->user->hasPermission('modify', 'module/kaafooter')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}	
	}
}
?>