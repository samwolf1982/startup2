<?php
// Text
$_['text_title']  = 'Доставка в зависимости от расстояния';
$_['text_weight'] = 'Вес:'; 
$_['km']  = ' км.';
$_['text_title_mileage_city'] = 'Доставка в пределах города';
$_['text_title_mileage_oblast'] = 'Доставка за город';
$_['mileage_description'] = 'Расстояние доставки';
$_['mileage_noaddress'] = '<em class="error" style="display: inline;">Для рассчета стоимости доставки укажите населенный пункт и адрес доставки.</em>';
$_['mileage_fault'] = '<em class="error" style="display: inline;">Не удалось рассчитать расстояние. Стоимость доставки Вы узнаете после оформления заказа.</em>';
$_['mileage_toofar'] = '<em class="error" style="display: inline;">Извините, мы не доставляем заказы дальше %d км. Выберите другой способ доставки.</em>';
?>
