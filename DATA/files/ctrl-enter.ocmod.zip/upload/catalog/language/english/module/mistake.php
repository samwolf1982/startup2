<?php
$_['mistake_title'] = 'Error in text!';
$_['mistake_comment'] = 'Your comments';
$_['mistake_send'] = 'Send';
$_['mistake_success'] = 'Thanks!';
$_['mistake_main_text'] = 'Watch text error on site? Select the text and click Ctrl+Enter!';