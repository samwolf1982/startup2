<?php
$_['mistake_title'] = 'Ошибка в тексте';
$_['mistake_comment'] = 'Ваш комментарий';
$_['mistake_send'] = 'Отправить';
$_['mistake_success'] = 'Спасибо!<br />Ваш комментарий отправлен!';
$_['mistake_main_text'] = 'Нашли ошибку ошибку в тексте? Выделите ее и нажмите Ctrl+Enter.';