<?php
// Heading
$_['heading_title']						= 'Загрузка файлов к заказу';
$_['common_title']						= 'Загрузка файлов к заказу';

// Text
$_['text_form']    						= 'Редактирование модуля';
$_['text_module']						= 'Модули';
$_['text_success']						= 'Успешно: Настройки модуля сохранены!';
$_['text_default']						= 'По умолчанию';
$_['text_upload']						= 'Загрузка файлов';
$_['text_add_filetype']					= 'Добавить тип файлов';
$_['text_no_results']					= 'Нет типов файлов!';
$_['text_delete']						= 'Удалить';
$_['text_confirm_delete']				= 'Подтвердить удаление';
$_['text_download']						= 'Загрузить';
$_['text_popup']						= 'Предпросмотр';
$_['text_empty']						= 'Ничего не загружено';
$_['text_drag_drop']    				= 'Перетащите файлы сюда';
$_['text_loading']    					= 'Загрузка...';
$_['text_complete']    					= 'Выполнено!';
$_['text_any']    						= 'Любой';
$_['text_rgb']    						= 'RGB';
$_['text_cmyk']    						= 'CMYK';
$_['text_width']    					= 'Ширина';
$_['text_height']    					= 'Высота';

$_['button_save_exit']					= 'Сохранить &amp; Выйти';
$_['button_add_copu_product']			= 'Добавить загрузку товару';
$_['button_add_filetype']				= 'Добавить';
$_['button_upload']						= 'Загрузить файл';

$_['tab_customer']						= 'Клиент';
$_['tab_order']							= 'Заказ';
$_['tab_product']						= 'Товар';
$_['tab_copu_product']					= 'Загрузить';
$_['tab_filetype']						= 'Типы файлов';

$_['entry_status']						= 'Статус:';
$_['entry_register']					= 'Загрузка в Регистрации:';
$_['entry_email_alert']					= 'Email уведомление:';
$_['entry_history_modify']				= 'Загрузки в Истории заказов клиента:';
$_['entry_history_modify_status']		= 'Статус заказа:';
$_['entry_history_modify_email_alert']	= 'Email уведомление о статусе заказа:';
$_['entry_drag_drop']					= 'Включить Drag &amp; Drop:';
$_['entry_multiple']					= 'Загрузка нескольких файлов:';
$_['entry_limit']						= 'Макс. кол-во файлов:';
$_['entry_minimum']						= 'Мин. кол-во файлов:';
$_['entry_files_per_page']				= 'Кол-во файлов на странице:';
$_['entry_min_filesize']				= 'Мин. объём файла:';
$_['entry_max_filesize']				= 'Макс. объём файла:';
$_['entry_max_dimension']				= 'Макс. рамзеры (Ш x В):';
$_['entry_image_channel']				= 'Цветвой канал изображения:';
$_['entry_max_filename_length'] 		= 'Максимальная длина имени файла:';
$_['entry_message']						= 'Инструкция к форме загрузки:';
$_['entry_preview']						= 'Предпросмотр загруженного изображения:';
$_['entry_preview_dimension']			= 'Размеры превью (Ш x В):';
$_['entry_filetype']					= 'Разрешенные типы файлов:';
$_['entry_replace']						= 'Заменить фото товара:';
$_['entry_login']						= 'Авторизация обязательна:';
$_['entry_customer_group']				= 'Группы клиентов:';
$_['entry_store']						= 'Магазины:';
$_['entry_ext']							= '<b>Формат:</b>';
$_['entry_mime']						= '<b>MIME:</b> <a href="http://filext.com" target="_blank">filext.com</a>';
$_['entry_upload_option']				= 'Опция товара:';
$_['entry_force_qty']					= 'Количество:';
$_['entry_customer_file_location']		= 'Папка для загрузки:';
$_['entry_order_file_location']			= 'Папка для загрузки:';
$_['entry_product_file_location']		= 'Папка для загрузки:';
$_['entry_customer_email_attachment']	= 'Отправлять файлы в прикреплении на Email:';
$_['entry_order_email_attachment']		= 'Отправлять файлы в прикреплении на Email:';
$_['entry_product_email_attachment']	= 'Отправлять файлы в прикреплении на Email:';

$_['help_email_alert']					= 'Адрес электронной почты можно задать в разделе «Система & gt; Настройки & gt; Ваш магазин [Изменить] & gt; Общие или Почта.';
$_['help_history_modify_email_alert']	= 'Адрес электронной почты можно задать в разделе «Система & gt; Настройки & gt; Ваш магазин [Изменить] & gt; Общие или Почта.';
$_['help_max_filesize']					= 'Пожалуйста, проверьте настройки сервера в файле php.ini, чтобы разрешить ограничение размера файла.';
$_['help_max_dimension']				= 'Только для типов файлов изображений. Вставьте 0 x 0 для неограниченного размера.';
$_['help_image_channel']				= 'Только для типов файлов изображений.';
$_['help_max_filename_length']			= 'Фактическое имя файла не будет сокращено. Только для внешнего вида будет: <br /> very...jpg вместо verylongfilename.jpg';
$_['help_message']						= 'Отобразите короткий текст перед полем загрузки.';
$_['help_replace']						= 'Только для типов файлов изображений.';
$_['help_ext']							= 'jpg, txt, psd';
$_['help_mime']							= 'Оставить пустым, чтобы отключить проверку MIME';
$_['help_force_qty']					= 'Количество товара в заказе равно количеству файлов, загруженных клиентом.';
$_['help_customer_file_location']		= 'Подкаталог: upload/files<br />By customer ID: files/%customer_id%';
$_['help_order_file_location']			= 'Подкаталог: upload/files<br />By customer ID: files/%customer_id%<br />By order ID: image/%order_id%';
$_['help_product_file_location']		= 'Подкаталог: upload/files<br />By customer ID: files/%customer_id%<br />By order ID: image/%order_id%<br />By product ID: uploads/%product_id%';
$_['help_customer_email_attachment']	= 'Будет отправлено при создании нового аккаунта';
$_['help_order_email_attachment']		= 'Будет отправлено при создании нового заказа';
$_['help_product_email_attachment']		= 'Будет отправлено при создании нового заказа';
//$_['help_']

$_['column_ext']						= 'Формат';
$_['column_mime']						= 'MIME';
$_['column_action']						= 'Действие';
$_['column_image']						= 'Изображение';
$_['column_name']						= 'Название';
$_['column_size']						= 'Размер';
$_['column_date']						= 'Дата добавления';

// Error
$_['error_permission']					= 'Предупреждение: у вас нет разрешения на модификацию модуля Загрузка файлов к заказу!';
$_['error_numeric']						= 'Пожалуйста, введите только цифры!';
$_['error_file_location']				= '%s не разрешено в папке %s!';
$_['error_submission']					= 'Внимание! Пожалуйста, внимательно проверьте форму на наличие ошибок!';
$_['error_delete']						= 'Ошибка удаления. Файл не найден!';
$_['error_filename']					= 'Имя файла должно быть от 3 до 64 символов!';
$_['error_upload']						= 'Загрузка обязательна!';

$_['myoc_copyright']					= '&nbsp;';
?>
