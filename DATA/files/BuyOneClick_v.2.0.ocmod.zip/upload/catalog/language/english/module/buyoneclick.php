<?php
$_['buyoneclick_field1_title'] = 'Name';
$_['buyoneclick_field2_title'] = 'Phone';
$_['buyoneclick_field3_title'] = 'E-mail';
$_['buyoneclick_field4_title'] = 'Message';
$_['buyoneclick_button_order'] = 'Send';
$_['buyoneclick_required_text'] = 'required field';
$_['buyoneclick_success'] = 'Thanks for your order!<br />We will contact you as soon as possible.';
$_['buyoneclick_error_required'] = 'Please, fill required fields!';
$_['buyoneclick_error_sending'] = 'Sending error, try again later!';