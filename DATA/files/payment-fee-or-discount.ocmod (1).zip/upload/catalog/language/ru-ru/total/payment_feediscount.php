<?php
$_['text_payment_fees'] 		= "Комиссия";
$_['text_payment_discounts'] 	= "Скидка";
$_['text_including_fees'] 		= " (учтено комиссию)";
$_['text_including_discounts'] 	= " (учтено скидку)";

?>