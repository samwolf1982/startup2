<?php
$_['text_payment_fees'] 		= "Payment fee";
$_['text_payment_discounts'] 	= "Payment discount";
$_['text_including_fees'] 		= " (including additional fees)";
$_['text_including_discounts'] 	= " (including discount)";

?>