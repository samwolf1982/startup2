<?php

// Text
$_['text_success']                  = '<strong>Success!</strong> Order status has been updated!';
$_['text_success_update']           = '<strong>Success!</strong> %s order(s) updated!';

// Error
$_['error_login']                   = '<strong>Error!</strong> Failed to log in with API key';
$_['error_failed_update']           = '<strong>Error!</strong> Failed to update %s order(s)!';
