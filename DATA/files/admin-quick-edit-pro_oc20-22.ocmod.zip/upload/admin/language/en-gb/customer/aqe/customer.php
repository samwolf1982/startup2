<?php

// Text
$_['text_success_delete']           = 'Success: %s customer(s) deleted!';

// Actions
$_['action_name']                   = 'Customer Name';
$_['action_approve']                = 'Approve';
$_['action_unlock']                 = 'Unlock';
$_['action_login']                  = 'Login into Store';
