<?php

// Text
$_['text_success_delete']           = 'Success: %s campaign(s) deleted!';

// Columns
$_['column_name']                   = 'Campaign Name';

// Errors
$_['error_name']                    = 'Warning: Campaign must be between 1 and 32 characters!';
