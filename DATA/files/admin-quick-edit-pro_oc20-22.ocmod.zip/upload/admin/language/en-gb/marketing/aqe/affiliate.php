<?php

// Text
$_['text_success_delete']           = 'Success: %s affiliate(s) deleted!';

// Actions
$_['action_name']                   = 'Affiliate Name';
$_['action_approve']                = 'Approve';
$_['action_unlock']                 = 'Unlock';
