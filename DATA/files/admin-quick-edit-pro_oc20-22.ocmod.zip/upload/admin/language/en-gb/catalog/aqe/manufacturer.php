<?php

// Text
$_['text_success_copy']             = 'Success: %s manufacturer(s) copied!';
$_['text_success_delete']           = 'Success: %s manufacturer(s) deleted!';

// Errors
$_['error_name']                    = 'Manufacturer Name must be between 2 and 64 characters!';
$_['error_delete']                  = '<strong>Warning!</strong> Manufacturer \'%s\' cannot be deleted as it is currently assigned to %s products!';
