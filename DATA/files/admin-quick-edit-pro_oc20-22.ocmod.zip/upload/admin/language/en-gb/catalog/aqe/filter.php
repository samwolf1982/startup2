<?php

// Text
$_['text_success_copy']             = 'Success: %s filter(s) copied!';
$_['text_success_delete']           = 'Success: %s filter(s) deleted!';

// Action
$_['action_group_name']             = 'Filter Group Name';
$_['action_filter_full']            = 'Filters';

// Errors
$_['error_group']                   = 'Filter Group Name must be between 1 and 64 characters!';
$_['error_name']                    = 'Filter Name must be between 1 and 64 characters!';
