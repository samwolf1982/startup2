<?php

// Text
$_['text_success_delete']           = 'Success: %s return(s) deleted!';

// Actions
$_['action_customer']               = 'Customer Name';
$_['action_customer_id']            = 'Customer Name';
