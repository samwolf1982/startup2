<?php

// Text
$_['text_success_delete']           = 'Success: %s gift voucher(s) deleted!';
$_['text_success_send']             = 'Success: %s gift voucher e-mail(s) have been sent!';

// Actions
$_['action_send']                   = 'Send';
