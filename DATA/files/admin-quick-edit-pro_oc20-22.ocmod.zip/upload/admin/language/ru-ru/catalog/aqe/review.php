<?php

// Text
$_['text_success_delete']           = 'Выполнено: %s отзыв(ы) удалены!';
