<?php

// Text
$_['text_success_copy']             = 'Выполнено: %s товар(ы) скопированы!';
$_['text_success_delete']           = 'Выполнено: %s товар(ы) удалены!';
$_['text_special_off']              = 'Текущая цена';
$_['text_special_active']           = 'Акционная цена установлена';
$_['text_special_expired']          = 'Период действия акционной цены истекает';
$_['text_special_future']           = 'Период действия акционной цены еще не наступил';
$_['text_name']                     = 'Название товара';
$_['text_tag']                      = 'Тэги товара';

// Text
$_['entry_downloads']               = 'Related Downloads';

// Errors
$_['error_name']                    = 'Название товара должно быть от 1 до 255 символов!';
