<?php

// Text
$_['text_success_delete']           = 'Выполнено: %s партнер(ы) удален(ы)!';

// Actions
$_['action_name']                   = 'Название партнера';
$_['action_approve']                = 'Утвержден';
$_['action_unlock']                 = 'Разблокирован';
