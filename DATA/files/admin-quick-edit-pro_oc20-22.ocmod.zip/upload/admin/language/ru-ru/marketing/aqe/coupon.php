<?php

// Text
$_['text_success_delete']           = 'Выполнено: %s купон(ы) удален(ы)!';

// Actions
$_['action_product']                = 'Товар';
$_['action_products']               = 'Товары';
$_['action_category']               = 'Категория';
$_['action_categories']             = 'Категории';
$_['action_prod']                   = 'P';
$_['action_cat']                    = 'C';
