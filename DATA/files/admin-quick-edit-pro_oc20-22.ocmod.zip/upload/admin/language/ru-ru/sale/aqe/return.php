<?php

// Text
$_['text_success_delete']           = 'Выполнено: %s возврат(ы) удален(ы)!';

// Actions
$_['action_customer']               = 'Имя покупателя';
$_['action_customer_id']            = 'Имя покупателя';
