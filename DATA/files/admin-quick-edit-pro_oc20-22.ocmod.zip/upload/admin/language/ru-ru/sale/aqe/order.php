<?php

// Text
$_['text_success']                  = '<strong>Выполнено!</strong> Статус заказа обновлен!';
$_['text_success_update']           = '<strong>Выполнено!</strong> %s заказ(ы) обновлен(ы)!';

// Error
$_['error_login']                   = '<strong>Ошибка!</strong> Не удалось авторизоваться с помощью ключа API';
$_['error_failed_update']           = '<strong>Ошибка!</strong> Не удалось обновить %s заказ(ы)!';
