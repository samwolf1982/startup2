<?php

// Text
$_['text_success_delete']           = 'Выполнено: %s voucher theme(s) deleted!';

// Actions
$_['action_name']                   = 'Voucher Theme Name';

// Errors
$_['error_name']                    = 'Voucher Theme Name must be between 3 and 32 characters!';
$_['error_delete']                  = '<strong>Warning!</strong> Voucher theme \'%s\' cannot be deleted as it is currently assigned to %s vouchers!';
