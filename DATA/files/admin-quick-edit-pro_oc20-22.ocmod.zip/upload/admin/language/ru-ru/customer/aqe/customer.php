<?php

// Text
$_['text_success_delete']           = 'Выполнено: %s покупатель(и) удален(ы)!';

// Actions
$_['action_name']                   = 'Имя покупателя';
$_['action_approve']                = 'Подтвердить';
$_['action_unlock']                 = 'Разблокировать';
$_['action_login']                  = 'Войти в магазин';
